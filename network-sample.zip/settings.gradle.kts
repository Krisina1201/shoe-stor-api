rootProject.name = "network-sample"
